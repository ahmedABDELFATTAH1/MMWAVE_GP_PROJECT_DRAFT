/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function showglobalsDoc()
{
    document.getElementById('contentframe').src = "globalsJSdoc/globals.js.html";
    window.scrollTo(0, 500);
}
function showscreen1sDoc()
{
    document.getElementById('contentframe').src = "screen1JSdoc/screen1.js.html";
}
function showconnectionDoc()
{
    document.getElementById('contentframe').src = "connectionJSdoc/connection.js.html";
}
function showcontrolssDoc()
{
    document.getElementById('contentframe').src = "controlsJSdoc/controls.js.html";
}
function showcameracontrolsDoc()
{
    document.getElementById('contentframe').src = "camcontrolsJSdoc/cameracontrols.js.html";
}